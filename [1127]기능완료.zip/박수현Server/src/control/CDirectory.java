package control;

import java.rmi.RemoteException;
import java.util.Vector;

import model.DataAccessObject;
import model.MDirectory;
import model.MModel;
import service.IDirectory;
import service.ILogin;
import valueObject.VDirectory;
import valueObject.VLogin;
import valueObject.VValueObject;

public class CDirectory  implements IDirectory {
    public CDirectory() throws RemoteException {
        super();
    }

	@Override
	
	public Vector<VDirectory> getData(String fileName) throws Exception{
		DataAccessObject dataAccessObject = new DataAccessObject();
		Vector<MModel> mModels = dataAccessObject.getModels(fileName, MDirectory.class);
		
		Vector<VDirectory> vDrectories = new Vector<VDirectory>();
		for (MModel mModel: mModels) {
			MDirectory mDirectory = (MDirectory) mModel;
			
			VDirectory vDirectory = new VDirectory(
				mDirectory.getName(),
				mDirectory.getFileName()
			);
			vDrectories.add(vDirectory);
		}		
		return vDrectories;
	}

}
