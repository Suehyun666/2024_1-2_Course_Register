package mainFrame;

import javax.swing.JButton;
import javax.swing.JToolBar;

public class PToolBar extends JToolBar {
	private static final long serialVersionUID = 1L;
	
	public PToolBar() {
		JButton button1 = new JButton("미리담기");
		this.add(button1);
	}

	public void initialize() {
		// TODO Auto-generated method stub
		
	}
}
