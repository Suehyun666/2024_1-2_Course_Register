package control;

import java.util.Vector;

import service.IResult;
import valueObject.VGangjwa;

public class CResult extends CContorl implements IResult{
	private IResult iResult;
	public CResult() throws Exception{	
		super();
		this.iResult=(IResult) this.registry.lookup(IResult.OBJECT_NAME);
	}
	
	public void save(String fileName, Vector<VGangjwa> vGangjwas) throws Exception{
		iResult.save(fileName, vGangjwas);
	}

	public Vector<VGangjwa> get(String fileName) throws Exception{
		return iResult.get(fileName);
	}

}
