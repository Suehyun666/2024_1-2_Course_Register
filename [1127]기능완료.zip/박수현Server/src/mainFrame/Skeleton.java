package mainFrame;

import java.rmi.AccessException;
import java.rmi.AlreadyBoundException;

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

import control.CResult;
import control.CDirectory;
import control.CGangjwa;
import control.CLogin;
import control.CUser;
import service.IDirectory;
import service.IGangjwa;
import service.ILogin;
import service.IResult;
import service.IUser;


public class Skeleton {
    Registry registry; 
    protected Skeleton() throws RemoteException {
        this.registry= LocateRegistry.createRegistry(Configuration.PORT_NUM);
       
    }
    private void register(String objectName, Remote object) throws AccessException, RemoteException, AlreadyBoundException {
    	Remote remote= UnicastRemoteObject.exportObject(object, 0); 
    	registry.bind(objectName, remote);
    }
    public void initialize() throws Exception {
        this.register(ILogin.OBJECT_NAME, new CLogin());
        this.register(IUser.OBJECT_NAME, new CUser());
        this.register(IDirectory.OBJECT_NAME, new CDirectory());
        this.register(IResult.OBJECT_NAME, new CResult());
        this.register(IGangjwa.OBJECT_NAME, new CGangjwa());
    }

    public void run() {
    	
    }
}
