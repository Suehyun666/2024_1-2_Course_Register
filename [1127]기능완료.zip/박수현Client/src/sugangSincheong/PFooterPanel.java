package sugangSincheong;

import javax.swing.JPanel;

public class PFooterPanel extends JPanel {
	private static final long serialVersionUID = 1L;

	public PFooterPanel() {
	}

	public void intialize() {
	}
}
