package control;
import java.rmi.RemoteException;

import model.DataAccessObject;
import model.MLogin;
import service.ILogin;
import valueObject.VLogin;
import valueObject.VResult;
import valueObject.VValueObject;

public class CLogin implements ILogin {
    public CLogin() throws RemoteException {
        super();
    }

	@Override
	public void initialze() throws RemoteException{
		
	}
	@Override
	public VResult login(VLogin vlogin) throws Exception{
		System.out.println("::server:: "+this.getClass().getSimpleName()+"::clogin");
		VResult vresult = new VResult();
		DataAccessObject dataAccessobject=new DataAccessObject();
		MLogin mLogin=(MLogin) dataAccessobject.getAModel("UserId", MLogin.class,vlogin.getUserId());
		if(mLogin!=null) {
			if (vlogin.getPassword().contentEquals(mLogin.getPassword())) {
				vresult.setSuccess(true); 
            } else {
            	vresult.setSuccess(false); 
            }
        } else {
        	vresult.setSuccess(false); 
        }

        return vresult;
    }

}
