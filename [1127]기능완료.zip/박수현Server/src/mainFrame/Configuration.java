package mainFrame;


public class Configuration {
	public final static int PORT_NUM=2347;

	public Configuration() {
		
		
	}

}
