package control;

import java.util.Vector;

import valueObject.VGangjwa;

public class CResult {

	public CResult() {		
	}
	
	public void save(String fileName, Vector<VGangjwa> vGangjwas) {
		
	}

	public Vector<VGangjwa> get(String fileName) {
		
		
		Vector<VGangjwa> vGangjwas = new Vector<VGangjwa>();
		
		return vGangjwas;
	}

}
