package model;

public class MUser extends MModel {
	private String userId;
	private String name;
	private String address;
	
	public MUser() {
	}

	public String getUserId() {
		return userId;
	}
	public String getName() {
		return name;
	}
	public String getAddress() {
		return address;
	}
}
