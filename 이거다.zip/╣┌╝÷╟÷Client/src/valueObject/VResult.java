package valueObject;


public class VResult extends VValueObject {
	private static final long serialVersionUID = 1L;

	public VResult() throws Exception{
	}
}
