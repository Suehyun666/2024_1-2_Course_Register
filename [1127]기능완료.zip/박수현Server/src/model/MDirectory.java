package model;

public class MDirectory extends MModel {
	private String id;
	private String name;
	private String fileName;
	
	public MDirectory() {
	}
	public String getId() {
		return id;
	}
	public String getName() {
		return name;
	}
	public String getFileName() {
		return fileName;
	}
}
