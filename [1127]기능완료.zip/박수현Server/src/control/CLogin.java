package control;
import java.rmi.RemoteException;

import model.DataAccessObject;
import model.MLogin;
import service.ILogin;
import valueObject.VLogin;
import valueObject.VValueObject;

public class CLogin implements ILogin {
    public CLogin() throws RemoteException {
        super();
    }

	@Override
	public void initialze() throws RemoteException{
		
	}
	@Override
	public VValueObject login(VLogin vlogin) throws Exception{
		System.out.println("::server:: "+this.getClass().getSimpleName()+"::clogin");
		VValueObject vValueObject = new VValueObject();
		DataAccessObject dataAccessobject=new DataAccessObject();
		MLogin mLogin=(MLogin) dataAccessobject.getAModel("UserId", MLogin.class,vlogin.getUserId());
		if(mLogin!=null) {
			if (vlogin.getPassword().contentEquals(mLogin.getPassword())) {
                vValueObject.setSuccess(true); 
            } else {
                vValueObject.setSuccess(false); 
            }
        } else {
            vValueObject.setSuccess(false); 
        }

        return vValueObject;
    }

}
