package control;

import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import constants.Configuration;
import service.ILogin;
import valueObject.VLogin;
import valueObject.VResult;
import valueObject.VValueObject;;

public class CLogin extends CContorl implements ILogin{

	private ILogin clogin;
	public CLogin() throws RemoteException, NotBoundException {
		this.clogin=(ILogin) this.registry.lookup(ILogin.OBJECT_NAME);}

	@Override
	public VResult login(VLogin vlogin) throws Exception {
		return clogin.login(vlogin);}

	@Override
	public void initialze() throws Exception {
		// TODO Auto-generated method stub
		
	}
}
