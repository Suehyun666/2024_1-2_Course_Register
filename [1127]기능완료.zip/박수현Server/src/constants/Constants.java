package constants;

public class Constants {
	
	public enum EConfigurations {
		miridamgiFilePostfix("M"),
		singcheongFilePostfix("S");
		
		private String text;
		private EConfigurations(String text) {
			this.text = text;
		}
		public String getText() {
			return this.text;
		}
		public int getInt() {
			return Integer.parseInt(text);
		}
	}
	
	
}
