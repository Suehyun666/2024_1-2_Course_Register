package model;

public class MLogin extends MModel {
	private String userId;
	private String password;
	
	public MLogin() {
	}

	public String getUserId() {
		return userId;
	}
	public String getPassword() {
		return password;
	}

}
