package mainFrame;



public class ExceptionManager {
	public ExceptionManager() {
		
	}
	public void process(Exception e) {
		
	}
	public void initialize() {
		// TODO Auto-generated method stub
		
	}

}
