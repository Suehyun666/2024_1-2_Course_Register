package mainFrame; 

public class Main {
	private Skeleton skeleton;

	public Main()  {	
		try {
			this.skeleton=new Skeleton();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.getStackTrace();
		}
	}
	private void initialize() throws Exception {
		this.skeleton.initialize();
		
	}
	private void run() {
		this.skeleton.run();
	}
	public static void main(String[] args) throws Exception {
		Main main =new Main();
		main.initialize();
		main.run();
	}
}
