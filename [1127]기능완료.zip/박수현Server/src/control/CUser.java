package control;

import java.rmi.RemoteException;

import model.DataAccessObject;
import model.MUser;
import service.IUser;
import valueObject.VUser;

public class CUser implements IUser {
	public CUser() throws Exception {
        super();
    }
	@Override
	public VUser getuser(String userid) throws Exception {
		DataAccessObject dataAccessObject = new DataAccessObject();
		MUser mUser = (MUser) dataAccessObject.getAModel(userid, MUser.class,userid);
		if (mUser != null) {
			VUser vUser = new VUser(mUser.getUserId(), mUser.getName(), mUser.getAddress());
			return vUser;
		}
		return null;
	}

	@Override
	public void initialze() throws Exception {
		// TODO Auto-generated method stub
		
	}
}
